# Ten Before/After Examples (RFOS)
(Condensed set. Each shows consensus‑first “Before” and RFOS “After.”)

1) Healthcare systems
Before: “Universal systems ensure access at lower cost.”
After (BLUF): Single‑payer cuts admin cost but fails under workforce shortages; U.S. hybrid fastest for insured but risky on costs; DE/JP hybrids balance best. Works when workforce stable; fails when aging + supply shortage. Two Lenses, Assumptions, Failure Modes, Tradeoffs, Labels.

2) Minimum wage
Before: “Reduces poverty with little job loss.”
After: Small hikes ok; large hikes shift to price/automation/hours cuts. Works when demand strong; fails in thin‑margin sectors.

3) Rent control
Before: “Keeps housing affordable.”
After: Protects incumbents; suppresses new supply; quality falls over time.

4) Carbon tax
Before: “Efficient way to cut emissions.”
After: Works when revenue is recycled and substitutes exist; fails with energy poverty or leakage.

5) Mass immigration
Before: “Boosts growth and innovation.”
After: GDP up; per‑capita depends on integration, skills, housing capacity.

6) Gun laws
Before: “More laws reduce crime.”
After: Effects hinge on enforcement and illegal market access; displacement risk.

7) Teacher unions
Before: “Protect quality.”
After: Pay/retention up; accountability/flexibility down without strong evaluation systems.

8) Lockdowns
Before: “Save lives.”
After: Short‑term spread control; long‑term costs include schooling, small‑biz, mental health.

9) EV subsidies
Before: “Accelerate transition.”
After: Work if grid/minerals scale; fail with transformer/apartment charging constraints.

10) AI safety neutrality
Before: “Prevents harm.”
After: Current norms embed elite worldview; neutrality needs dual‑framework outputs.
