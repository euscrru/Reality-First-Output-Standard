# Press Note — Reality‑First Output Standard (RFOS)
What: Minimal, open spec for reality‑grounded answers.  
Why: Trust requires showing where systems fail, not just how they should work.  
How: BLUF, Two Lenses, Assumptions, Failure Modes, Tradeoffs, Confidence/Contestation, Sources Mix.  
License: MIT. Contact: (add author details). 
